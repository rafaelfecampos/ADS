
public enum ETipoCorCabelo
{
    LOIRO, CASTANHO, PRETO;
}
