public class Main {
    public static void main(String[] args){

        Data data = new Data(0,5,2022);
        data.avancarDia();
        System.out.println(data.toString());

    }
}