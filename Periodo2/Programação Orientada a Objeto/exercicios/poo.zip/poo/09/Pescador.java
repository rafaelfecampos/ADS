
public class Pescador
{
    private double pesoPeixe;
    
    public Pescador(){
        
    }
    public Pescador(double pesoPeixe){
        this.pesoPeixe = pesoPeixe;
    }
    
    public double getPesoPeixe(){
        return pesoPeixe;
    }
    public void setPesoPeixe(double pesoPeixe){
        this.pesoPeixe = pesoPeixe;
    }
}
