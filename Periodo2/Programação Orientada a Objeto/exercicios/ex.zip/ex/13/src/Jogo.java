public class Jogo {
    private char resultado;

    public Jogo(char resultado) {
        this.resultado = resultado;
    }

    public char getResultado() {
        return resultado;
    }

    public void setResultado(char resultado) {
        this.resultado = resultado;
    }
}
