package org.exercicios.ex7;

public class Emprestimo {

    private double valorEmprestimo;
    private int numMeses;
    private Banco banco;

    public Emprestimo() {}
    public Emprestimo(double valorEmprestimo, int numMeses, Banco banco) {
        this.valorEmprestimo = valorEmprestimo;
        this.numMeses = numMeses;
        this.banco = banco;
    }

    public double valorMensal(){
        double juros = 1.10;
        double valorPorMes = valorEmprestimo/numMeses;
        if (numMeses > 6){
            //Com juros
            return valorPorMes * juros;
        } else
            return valorPorMes;
    }

    public double valorTotalAPagar(){
        return valorMensal() * numMeses;
    }

    public double valorMensalDeJuros(){
        if (numMeses < 6)
            return 0;
        else
            return valorMensal() - (valorEmprestimo/numMeses);
    }

    public double getValorEmprestimo() {
        return valorEmprestimo;
    }

    public void setValorEmprestimo(double valorEmprestimo) {
        this.valorEmprestimo = valorEmprestimo;
    }

    public int getNumMeses() {
        return numMeses;
    }

    public void setNumMeses(int numMeses) {
        this.numMeses = numMeses;
    }
}
