package org.exercicios.ex1;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        //Crie um programa que calcule a distância entre dois pontos no plano cartesiano.

        Scanner sc = new Scanner(System.in);
        int[] ponto1 = new int[2];
        int[] ponto2 = new int[2];

        System.out.println("--= Ponto 1 =--");
        leCoords(ponto1, sc);
        System.out.println("--= Ponto 2 =--");
        leCoords(ponto2, sc);

        double distancia = calculaDistancia(ponto1, ponto2);

        System.out.println("Distancia entre o ponto 1 e o ponto 2: " + distancia);
        sc.close();
    }

    static void leCoords(int[] vet, Scanner sc){
        for (int i = 0; i < 2; i++){
            System.out.print("X" + (i+1) + ": ");
            vet[i] = sc.nextInt();
        }
    }

    static double calculaDistancia(int[] ponto1, int[] ponto2){
        return Math.sqrt(Math.pow((ponto1[1] - ponto1[0]), 2) + Math.pow((ponto2[1] - ponto2[0]), 2));
    }
}