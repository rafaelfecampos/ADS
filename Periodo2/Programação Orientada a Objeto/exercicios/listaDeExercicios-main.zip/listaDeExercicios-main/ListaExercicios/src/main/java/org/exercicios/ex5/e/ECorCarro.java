package org.exercicios.ex5.e;

public enum ECorCarro {
    ESPECIAL, METALICA, COMEMORATIVA;
}
