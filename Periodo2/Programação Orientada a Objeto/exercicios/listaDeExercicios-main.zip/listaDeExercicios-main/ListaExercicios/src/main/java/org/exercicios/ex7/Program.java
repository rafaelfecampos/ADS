package org.exercicios.ex7;

import java.sql.SQLOutput;
import java.util.Scanner;

public class Program {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Banco banco = new Banco("Banco A", 0);

        System.out.println(" FAÇA UM EMPRESTIMO ");
        System.out.print("Nome: ");
        String nome = sc.nextLine();
        Pessoa p = new Pessoa(nome, banco);
        System.out.print("Deseja fazer um empréstimo de quantos reais? R$");
        double valorEmprestimo = sc.nextDouble();
        p.fazerEmprestimo(valorEmprestimo);
        System.out.print("Quer pagar em quantos meses? ( até 6x sem juros ): ");
        int numMeses = sc.nextInt();
        banco.addEmprestimos( new Emprestimo(valorEmprestimo, numMeses, banco) );

        System.out.println();
        System.out.println(" -== INFORMAÇÕES DO EMPRÉSTIMO ==- ");
        System.out.println();

        if (banco.valorTotalDeJuros() != 0){
            double totalJurosPago = 0;
            double totalPago = 0;
            for (int i = 0; i < banco.numMeses(); i++) {
                System.out.println(" ----- MES 0" + (i+1) + " -----");
                p.pagarEmprestimo(banco.valorMensal());
                totalPago += banco.valorMensal();
                System.out.println("Valor total de juros: R$" + banco.valorTotalDeJuros());
                totalJurosPago += banco.valorMensalDeJuros();
                System.out.println("Valor da divida: R$" + banco.valorTotal());
                System.out.println("Juros já pagos: R$" + totalJurosPago);
                System.out.println("Valor total já pago: R$" + totalPago);
                System.out.println("Valor ainda a pagar: R$" + (banco.valorTotal() - totalPago));
                System.out.println("--------------------------------");
            }
        } else {
            System.out.println("Emprestimo sem juros!");
            double totalPago = 0;
            for (int i = 0; i < banco.numMeses(); i++) {
                System.out.println(" ----- MES 0" + (i+1) + " -----");
                p.pagarEmprestimo(banco.valorMensal());
                totalPago += banco.valorMensal();
                System.out.println("Valor aplicado no pagamento da dívida: " + banco.valorTotal());
                System.out.println("Valor total já pago: R$" + totalPago);
                System.out.println("Valor ainda a pagar: " + (banco.valorTotal() - totalPago));
            }
        }


        sc.close();
    }
}
