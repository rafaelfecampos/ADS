package org.exercicios.ex6;

public class Empregado {

    private String nome;
    private int anoNascimento;
    private int anoInicioTrabalho;

    public Empregado() {}

    public Empregado(String nome, int anoNascimento, int anoInicioTrabalho) {
        this.nome = nome;
        this.anoNascimento = anoNascimento;
        this.anoInicioTrabalho = anoInicioTrabalho;
    }

    public boolean podeAposentar(){
        int idade = 2023 - anoNascimento;
        int tempoDeTrabalho = 2023 - anoInicioTrabalho;

        if (idade >= 65)
            return true;
        else if (tempoDeTrabalho >= 30)
            return true;
        else if (idade >= 60 && tempoDeTrabalho >= 25)
            return true;

        return false;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getAnoNascimento() {
        return anoNascimento;
    }

    public void setAnoNascimento(int anoNascimento) {
        this.anoNascimento = anoNascimento;
    }

    public int getAnoInicioTrabalho() {
        return anoInicioTrabalho;
    }

    public void setAnoInicioTrabalho(int anoInicioTrabalho) {
        this.anoInicioTrabalho = anoInicioTrabalho;
    }
}
