package org.exercicios.ex7;

public class Pessoa {

    private String nome;
    private double valor;

    private Banco banco;
    public Pessoa() {}

    public Pessoa(String nome, Banco banco) {
        this.nome = nome;
        this.banco = banco;
    }

    public Pessoa(String nome, double valor, Banco banco) {
        this.nome = nome;
        this.valor = valor;
        this.banco = banco;
    }

    public void fazerEmprestimo(double valorEmprestimo){
        valor -= valorEmprestimo;
    }

    public void pagarEmprestimo(double valorAPagar){
        banco.receber(valorAPagar);
        valor -= valorAPagar;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Banco getBanco() {
        return banco;
    }

    public void setBanco(Banco banco) {
        this.banco = banco;
    }
}
