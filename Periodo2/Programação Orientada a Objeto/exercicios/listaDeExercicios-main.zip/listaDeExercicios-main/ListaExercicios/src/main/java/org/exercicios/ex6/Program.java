package org.exercicios.ex6;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("--= CADASTRE UM EMPREGADO =--");
        System.out.println();
        System.out.print("Nome: ");
        String nome = sc.next();
        System.out.print("Ano de nascimento (AAAA): ");
        int anoNasc = sc.nextInt();
        System.out.print("Ano que começou a trabalhar (AAAA): ");
        int anoInicioTrabalho = sc.nextInt();
        Empregado emp = new Empregado(nome, anoNasc, anoInicioTrabalho);

        if (emp.podeAposentar())
            System.out.println("O empregado cadastrado pode se aposentar.");
        else
            System.out.println("O empregado cadastrado ainda não pode se aposentar.");

        sc.close();
    }
}
