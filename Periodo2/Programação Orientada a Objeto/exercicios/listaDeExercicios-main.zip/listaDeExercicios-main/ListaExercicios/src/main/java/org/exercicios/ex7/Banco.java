package org.exercicios.ex7;

import java.util.ArrayList;

public class Banco {

    private String nome;
    private double montante;

    private ArrayList<Emprestimo> emprestimos;

    public Banco(String nome, double montante) {
        this.nome = nome;
        this.emprestimos = new ArrayList<>();
        this.montante = montante;
    }

    public Banco(String nome, double montante, ArrayList<Emprestimo> emprestimos) {
        this.nome = nome;
        this.montante = montante;
        this.emprestimos = new ArrayList<>();
    }

    public double valorMensal(){
        for (Emprestimo e : emprestimos){
            return e.valorMensal();
        }
        return 0;
    }

    public double valorTotal(){
        for (Emprestimo e : emprestimos){
            return valorMensal() * e.getNumMeses();
        }

        return 0;
    }

    public double valorMensalDeJuros(){
        for (Emprestimo e : emprestimos ){
            return e.valorMensalDeJuros();
        }
        return 0;
    }
    public double valorTotalDeJuros(){
        for (Emprestimo e : emprestimos ){
            return e.getNumMeses() * e.valorMensalDeJuros();
        }
        return 0;
    }

    public int numMeses(){
        for (Emprestimo e : emprestimos){
            return e.getNumMeses();
        }
        return 0;
    }

    public void receber(double valorPago){
        this.montante += valorPago;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getMontante() {
        return montante;
    }

    public ArrayList<Emprestimo> getEmprestimos() {
        return emprestimos;
    }

    public void addEmprestimos(Emprestimo emprestimo) {
        emprestimos.add(emprestimo);
    }


}
