package org.exercicios.ex5;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        //Crie um aplicativo que permita ao consumidor customizar a escolha de um carro
        //novo com seus opcionais, câmbio automático, vidro automático, alarme, teto solar, kit
        //multimídia, potência do motor, dentre outros opcionais. Ao final mostre os detalhes do
        //carro escolhido e o custo do carro conforme o cálculo a seguir:
        //O preço do carro depende do modelo, acrescido IPI, 20% do custo final do veículo, se for
        //importante ainda é taxado em 30% sobre o preço. Veículos com motores 1.0 o IPI é
        //reduzido a 10%.
        //Cada acessório opcional acrescenta seu custo ao veículo, segue a tabela de preço
        //abaixo:
        //Ar -> R$ 3.000,00, câmbio automático -> R$ 5.000,00, alarme -> R$ 800,00, pintura
        //especial, metálica ou comemorativa -> R$ 2.500,00, teto solar -> R$ 4.000,00 e kit
        //multimidia -> R$ 1.800,00

        Scanner sc = new Scanner(System.in);
        Carro carro = new Carro();

        System.out.println("--= COMPRE UM VEÍCULO PERSONALIZADO =--");
        System.out.println(" - Selecione as opções que deseja -");
        int escolha = -1;
        menu();

        while (escolha != 0){
            System.out.print("Opção: ");
            escolha = sc.nextInt();
            switch (escolha){
                case 1:
                    carro.setCambio(true);
                    System.out.println("* Câmbio Automático adicionado *");
                    break;
                case 2:
                    carro.setVidro(true);
                    System.out.println("* Vidro Automático adicionado *");
                    break;
                case 3:
                    carro.setAlarme(true);
                    System.out.println("* Alarme adicionado *");
                    break;
                case 4:
                    carro.setTeto(true);
                    System.out.println("* Teto Solar adicionado *");
                    break;
                case 5:
                    carro.setKit(true);
                    System.out.println("* Kit Multimídia adicionado *");
                    break;
                case 6:
                    System.out.print("Digite a potencia que deseja\n(1.0 | 1.5 | 2.0): ");
                    String pot = sc.next();
                    carro.setPotencia(pot);
                    System.out.println("* Potência de " + carro.getPotencia() + " adicionada *");
                    break;
                case 7:
                    System.out.print("Digite a pintura que deseja\n(ESPECIAL, METALICA, COMEMORATIVA): ");
                    String cor = sc.next();
                    carro.setCor(cor.toUpperCase());
                    System.out.println("* Pintura " + cor + " adicionada *");
                    break;
                case 8:
                    carro.setAr(true);
                    System.out.println("* Ar Condicionado adicionado *");
                    break;
            }
        }

        System.out.println("Obrigado por comprar conosco!");
        System.out.println(carro);
        System.out.printf("Valor final do carro: R$%.2f%n", carro.precoVenda());


        sc.close();
    }

    static void menu(){
        System.out.println("[1] Câmbio Automático");
        System.out.println("[2] Vidro  Automático");
        System.out.println("[3] Alarme");
        System.out.println("[4] Teto Solar");
        System.out.println("[5] Kit Multimídia");
        System.out.println("[6] Escolher potência do motor");
        System.out.println("[7] Pintura");
        System.out.println("[8] Ar");
        System.out.println("[0] _SAIR_");
    }
}
