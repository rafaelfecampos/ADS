package org.exercicios.ex3;

import java.util.Scanner;

public class Program {
    public static void main(String[] args){
        //Crie um programa para ler os 3 lados de um triângulo, ao final imprima sua área, seu
        //perímetro e o tipo de triângulo. Isósceles, Escaleno ou Equilátero

        Scanner sc = new Scanner(System.in);

        double l1, l2, l3;

        System.out.println("-- Lendo dados de um triângulo --");
        System.out.println("Lado 1: ");
        l1 = sc.nextDouble();
        System.out.println("Lado 2: ");
        l2 = sc.nextDouble();
        System.out.println("Lado 3: ");
        l3 = sc.nextDouble();
        System.out.println();
        System.out.printf("Área: %.2f%n", areaTriangulo(l1, l2, l3));
        double perimetro = l1+l2+l3;
        System.out.println("Perímetro: " + perimetro);
        System.out.println("Tipo: " + tipoDeTriangulo(l1, l2, l3));

        sc.close();
    }


    static double areaTriangulo(double l1, double l2, double l3){
        double semip = (l1 + l2 + l3)/2;
        double area = Math.sqrt(semip * (semip - l1) * (semip - l2) * (semip * l3));

        return area;
    }
    static String tipoDeTriangulo(double l1, double l2, double l3){
        String tipo;
        int cont = 0;
        if (l1 != l2 && l1 != l3 && l2 != l3){
            tipo = "Escaleno";
        } else if (l1 == l2 && l2 == l3 && l1 == l3)
            tipo = "Equilátero";
        else
            tipo = "Isósceles";
        return tipo;
    }
}
