package org.exercicios.ex4;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        //Crie um programa de determine se uma pessoa possui uma idade superior a 18 anos.
        //O usuário deverá informar o nome, ano de nascimento e email da pessoa. Faça uso da
        //classe acima.

        Scanner sc = new Scanner(System.in);

        System.out.println("-- Lendo dados de uma pessoa --");
        System.out.println();
        System.out.print("Nome: ");
        String nome = sc.nextLine();
        System.out.print("Ano de nascimento: ");
        int anoNasc = sc.nextInt();
        System.out.print("Email: ");
        sc.next();
        String email = sc.nextLine();

        Pessoa pessoa = new Pessoa(nome, anoNasc, email);

        if (pessoa.maioridade()){
            System.out.println("Maior de 18.");
        } else
            System.out.println("Menor de 18.");

        sc.close();
    }
}
