package org.exercicios.ex5;

import org.exercicios.ex5.e.ECorCarro;

public class Carro {
    private boolean cambio, vidro, alarme, teto, kit, ar;
    private ECorCarro cor;
    private String potencia;
    private double preco;

    public Carro() {}

    public Carro(boolean cambio, boolean vidro, boolean alarme, boolean teto, boolean kit, String cor, String potencia, boolean ar) {
        this.cambio = cambio;
        this.vidro = vidro;
        this.alarme = alarme;
        this.teto = teto;
        this.kit = kit;
        this.cor = ECorCarro.valueOf(cor);
        this.potencia = potencia;
        this.ar = ar;
    }

    public double precoVenda(){
        if (cambio){
            preco += 5000.00;
        } if (vidro){
            preco += 1500.00;
        } if (alarme){
            preco += 800.00;
        } if (teto){
            preco += 4000.00;
        } if (kit){
            preco += 1800.00;
        } if (ar){
            preco += 3000.00;
        } if (potencia.equals("1.0")){
            preco += 15000.00;
        } if (potencia.equals("1.5")){
            preco += 25000.00;
        } if (potencia.equals("2.0")){
            preco += 35000.00;
        } if (cor != null){
            preco += 2500.00;
        }
        return preco;
    }

    public boolean isAr() {
        return ar;
    }

    public void setAr(boolean ar) {
        this.ar = ar;
    }

    public boolean isCambio() {
        return cambio;
    }

    public void setCambio(boolean cambio) {
        this.cambio = cambio;
    }

    public boolean isVidro() {
        return vidro;
    }

    public void setVidro(boolean vidro) {
        this.vidro = vidro;
    }

    public boolean isAlarme() {
        return alarme;
    }

    public void setAlarme(boolean alarme) {
        this.alarme = alarme;
    }

    public boolean isTeto() {
        return teto;
    }

    public void setTeto(boolean teto) {
        this.teto = teto;
    }

    public boolean isKit() {
        return kit;
    }

    public void setKit(boolean kit) {
        this.kit = kit;
    }

    public ECorCarro getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = ECorCarro.valueOf(cor);
    }

    public String getPotencia() {
        return potencia;
    }

    public void setPotencia(String potencia) {
        this.potencia = potencia;
    }

    public double getPreco() {
        return preco;
    }


    @Override
    public String toString() {
        return "Carro{" +
                "Cambio=" + cambio +
                ", vidro=" + vidro +
                ", alarme=" + alarme +
                ", teto=" + teto +
                ", kit=" + kit +
                ", cor=" + cor +
                ", potencia='" + potencia + '\'' +
                '}';
    }
}
